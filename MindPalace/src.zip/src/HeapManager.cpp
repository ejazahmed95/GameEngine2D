#include "HeapManager.h"

#include <iostream>

void* HeapManager::alloc(size_t size) {
	void* ptr = _freePtr;
	_freePtr = nullptr;
	return ptr;
}

void HeapManager::collect() {

}

void HeapManager::Assign(void* start, size_t size, int num_descriptors) {
	_freePtr = start;
	_heapSize = size;
	_numDescriptors = num_descriptors;
}

char* WriteChars(char* ch, const char* str) {
	int i = 0;
	while(str[i] != '\0') {
		*ch = str[i];
		ch++;
		i++;
	}
	return ch;
}

HeapManager* CreateHeapManager(void* pHeapMemory, size_t heapSize, int numDescriptors) {

	char* ch = static_cast<char*>(pHeapMemory);
	ch = WriteChars(ch, "HEAP");
	HeapManager* hm = (HeapManager*)(ch);
	size_t hSize = sizeof(HeapManager) + static_cast<size_t>(8);

	std::cout << "HSize=" << hSize << "||| Available Size=" << heapSize - hSize << std::endl;
	std::cout << "Start mem location = " << pHeapMemory << std::endl;
	hm->Assign(static_cast<char*>(pHeapMemory) + hSize, heapSize - hSize, numDescriptors);
	ch += sizeof(HeapManager);
	ch = WriteChars(ch, "HEAP"); 
	return hm;
}
