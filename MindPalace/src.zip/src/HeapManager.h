#pragma once

class HeapManager {
private:
	size_t _heapSize;
	int _numDescriptors;
	void* _freePtr;
public:
	void* alloc(size_t size);
	void collect();
	void Assign(void* start, size_t size, int num_descriptors);
};

HeapManager* CreateHeapManager(void* pHeapMemory, size_t heapSize, int numDescriptors);
char* WriteChars(char* ch, const char* str);
bool HeapManager_CustomTest(void* heapStart, size_t sizeHeap, int num_descriptors);